import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, GeoJSON, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import "./MapComponent.css";
import xaPhuongData from '../data/quangtri-xaphuong.json';
import WeatherChart from './WeatherChart';
import { saveAs } from 'file-saver';

function MapComponent() {
  const [selectedFeature, setSelectedFeature] = useState(null);
  const [weatherData, setWeatherData] = useState(null);
  const [weatherOW, setWeatherOW] = useState(null);
  const [weatherById, setWeatherById] = useState({});
  const [selectedDate, setSelectedDate] = useState('');

  const OPENWEATHER_KEY = '724acaddbed244f61b696130723cd9a3';

  useEffect(() => {
    const fetchAllWeather = async () => {
      const results = {};
      for (const feature of xaPhuongData.features) {
        const name = feature.properties.ten;
        const geojsonLayer = L.geoJSON(feature);
        const center = geojsonLayer.getBounds().getCenter();
        const lat = center.lat;
        const lng = center.lng;
        try {
          const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&daily=temperature_2m_max&timezone=auto`);
          const data = await res.json();
          results[name] = data.daily?.temperature_2m_max?.[0] || null;
        } catch {
          results[name] = null;
        }
      }
      setWeatherById(results);
    };
    fetchAllWeather();
  }, []);

  const getColorByTemperature = (temp) => {
    if (temp == null) return '#ccc';
    if (temp > 37) return '#ff0000';
    if (temp > 33) return '#ff8000';
    if (temp > 28) return '#ffff00';
    if (temp > 22) return '#80ff00';
    return '#00ffff';
  };

  const geoJsonStyle = (feature) => {
    const name = feature.properties.ten;
    const temp = weatherById[name];
    const color = getColorByTemperature(temp);
    return { color: '#000', weight: 1, fillColor: color, fillOpacity: 0.6 };
  };

  const fetchWeather = async (center) => {
    const lat = center.lat;
    const lon = center.lng;
    let urlMeteo = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&hourly=temperature_2m,precipitation,windspeed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,windspeed_10m_max&timezone=auto`;
    if (selectedDate) urlMeteo += `&start_date=${selectedDate}&end_date=${selectedDate}`;
    let urlOW = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${OPENWEATHER_KEY}&units=metric`;

    try {
      const resMeteo = await fetch(urlMeteo);
      const dataMeteo = await resMeteo.json();
      setWeatherData(dataMeteo);
    } catch (err) {
      console.error('Lỗi Open-Meteo:', err);
    }

    try {
      const resOW = await fetch(urlOW);
      const dataOW = await resOW.json();
      setWeatherOW(dataOW);
    } catch (err) {
      console.error('Lỗi OpenWeather:', err);
    }
  };

  const exportForecastToCSV = () => {
    if (!weatherData?.hourly || !selectedFeature?.name) return;
    const rows = [];
    const { time, temperature_2m, precipitation, windspeed_10m } = weatherData.hourly;
    const regionName = selectedFeature.name;

    for (let i = 0; i < time.length; i++) {
      rows.push({
        time: time[i],
        temperature_2m: temperature_2m[i],
        precipitation: precipitation[i],
        windspeed_10m: windspeed_10m[i],
        region_name: regionName
      });
    }

    const header = Object.keys(rows[0]).join(",");
    const csv = [
      header,
      ...rows.map(row => Object.values(row).join(","))
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, `${regionName.replace(/\s+/g, '_')}_dubaotheogio.csv`);
  };

  const aggregateOWDaily = () => {
    if (!weatherOW?.list) return null;

    let tmax = -Infinity, tmin = Infinity, rainSum = 0, windSum = 0, count = 0;

    for (const item of weatherOW.list) {
      const dateStr = item.dt_txt.split(' ')[0];
      const todayStr = new Date().toISOString().split('T')[0];
      if (dateStr === todayStr) {
        const temp = item.main.temp;
        const rain = item.rain?.['3h'] || 0;
        const wind = item.wind.speed;

        if (temp > tmax) tmax = temp;
        if (temp < tmin) tmin = temp;
        rainSum += rain;
        windSum += wind;
        count += 1;
      }
    }

    if (count === 0) return null;

    return {
      tmax: tmax.toFixed(1),
      tmin: tmin.toFixed(1),
      rain: rainSum.toFixed(1),
      wind: (windSum / count).toFixed(1),
    };
  };

  const handleFeatureClick = async (e) => {
    const feature = e.target.feature;
    const center = e.target.getBounds().getCenter();
    setSelectedFeature({ center, name: feature.properties.ten });
    setWeatherData(null);
    setWeatherOW(null);
    await fetchWeather(center);
  };

  const onEachFeature = (feature, layer) => {
    layer.on({ click: handleFeatureClick });
  };

  const handleRefresh = () => {
    if (selectedFeature) fetchWeather(selectedFeature.center);
  };

  const renderPopup = () => {
    if (!selectedFeature) return null;

    if (!weatherData?.daily || !weatherOW?.list) {
      return (
        <Popup position={selectedFeature.center}>
          <div style={{ padding: '10px' }}>⏳ Đang tải dữ liệu dự báo...</div>
        </Popup>
      );
    }

    const { center, name } = selectedFeature;
    const daily = weatherData.daily;
    const tmax = daily.temperature_2m_max[0];
    const tmin = daily.temperature_2m_min[0];
    const rain = daily.precipitation_sum[0];
    const wind = daily.windspeed_10m_max[0];

    const owDaily = aggregateOWDaily();

    return (
      <Popup position={center}>
        <div style={{
          fontSize: '16px', fontWeight: 'bold', lineHeight: '1.5',
          color: '#333', border: '3px solid #2196f3', borderRadius: '8px',
          padding: '10px', background: '#f5f5f5',
          boxShadow: '0 2px 10px rgba(0,0,0,0.3)'
        }}>
          <div style={{ fontSize: '18px', color: '#2196f3' }}>{name}</div>
          <div style={{ fontSize: '14px', marginBottom: '8px', fontWeight: 'normal' }}>
            Ngày dự báo: {selectedDate || 'Hôm nay'}
          </div>

          <div style={{ fontWeight: 'bold' }}>Trị số dự báo:</div>
          <div>🌡️ Tmax: {tmax}°C</div>
          <div>🌡️ Tmin: {tmin}°C</div>
          <div>☔ Mưa: {rain} mm</div>
          <div>💨 Gió: {(wind / 3.6).toFixed(1)} m/s</div>

          {owDaily && (
            <>
              <div style={{ fontWeight: 'bold', marginTop: '8px' }}>OpenWeather (Hôm nay):</div>
              <div>🌡️ Tmax: {owDaily.tmax}°C</div>
              <div>🌡️ Tmin: {owDaily.tmin}°C</div>
              <div>☔ Mưa: {owDaily.rain} mm</div>
              <div>💨 Gió TB: {owDaily.wind} m/s</div>
            </>
          )}

          <div style={{ marginTop: '10px' }}>
            <button onClick={exportForecastToCSV} style={{ fontSize: '14px', padding: '6px 10px', cursor: 'pointer' }}>📥 Tải CSV dự báo giờ</button>
          </div>
        </div>
      </Popup>
    );
  };

  return (
    <div>
      <MapContainer center={[16.75, 107.1]} zoom={8} className="responsive-map">
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <GeoJSON data={xaPhuongData} onEachFeature={onEachFeature} style={geoJsonStyle} />
        {renderPopup()}
      </MapContainer>

      <div style={{ padding: '10px', textAlign: 'center' }}>
        <div style={{
          marginBottom: '8px',
          fontStyle: 'italic',
          fontWeight: 'bold',
          textAlign: 'center',
          color: '#007bff',
          fontSize: '16px'
        }}>
          Chọn ngày dự báo và nhớ click nút Làm mới
        </div>
        <button onClick={handleRefresh}>🔁 Làm mới</button>
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          style={{ marginLeft: '10px' }}
        />
      </div>

      {weatherData?.hourly && (
        <div style={{ padding: '10px' }}>
          <WeatherChart hourly={weatherData.hourly} regionName={selectedFeature.name} />
        </div>
      )}
    </div>
  );
}

export default MapComponent;
